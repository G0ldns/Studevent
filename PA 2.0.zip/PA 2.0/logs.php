<?php 
session_start();
	require "conf.inc.php";
	require "core/functions.php";
    include "template/header.php";
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" type="image/x-icon" href="assets/Log PAsf.jpg" />
    <title>STUDEVENT</title>
    <link rel="stylesheet" href="logs.css">


</head>
<body>

<div class="container">

<?php

	$connection = connectDB();
	$results = $connection->query("SELECT * FROM ".DB_PREFIX."logs");
	$results = $results->fetchAll()
?>

<?php
    $connection = connectDB();
    $results = $connection->query("SELECT * FROM ".DB_PREFIX."logs");
    $results = $results->fetchAll();

?>


<!-- Ajout du compteur de logs -->

<table class="table">

	<thead>
		<tr>
			<th>Total de logs :</th>
			<th><?php echo count($results); ?></th>
		</tr>
	</thead>
</table>

<!------------------------------------------------------------------------------------------------>
<?php
    $connection = connectDB();
    $results = $connection->query("SELECT * FROM ".DB_PREFIX."logs");
    $results = $results->fetchAll();

    // Initialisation du tableau pour compter les visites par page
    $pageVisits = [];

    // Comptage des visites par page
    foreach ($results as $log) {
        if (!isset($pageVisits[$log["page_visited"]])) {
            $pageVisits[$log["page_visited"]] = 0;
        }
        $pageVisits[$log["page_visited"]]++;
    }
?>

<!-- Affichage du nombre de visites par page -->
<table class="table">

	<thead>
		<tr>
			<th>Nombre de visites par page :</th>
    		<?php foreach ($pageVisits as $page => $visits) : ?>
        	<th><?php echo htmlspecialchars($page); ?> : <?php echo $visits; ?></th>
    		<?php endforeach; ?>
		</tr>
	</thead>
</table>
<!------------------------------------------------------------------------------------------------>

<!--Tableau des logs-->

<table class="table">
	<thead>
		<tr>
			<th>Id</th>
			<th>Date</th>
			<th>Heure</th>
			<th>Ip</th>
			<th>Page</th>
			<th>Utilisateurs</th>
		</tr>
	</thead>
	<tbody>
		<?php

		foreach ($results as $logs) {
			echo "<tr>";
			echo "<td>".$logs["id"]."</td>";
			echo "<td>".$logs["visit_date"]."</td>";
			echo "<td>".$logs["visit_hour"]."</td>";
			echo "<td>".$logs["ip"]."</td>";
			echo "<td>".$logs["page_visited"]."</td>";
			echo "<td>".$logs["user"]."</td>";
			echo "</tr>";
		}

		?>
		
	</tbody>
</table>



<?php include "template/footer.php";?>
