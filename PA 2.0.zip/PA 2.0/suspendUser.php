<?php
session_start();
require "conf.inc.php";
require "core/functions.php";

if (!isset($_GET["id"])) {
    // Redirigez l'utilisateur vers une page d'erreur ou la page précédente si l'ID n'est pas défini
    header("Location: error.php");
    exit();
}

$userId = $_GET["id"];
$connection = connectDB();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["duration"])) {
        $duration = intval($_POST["duration"]);
        $suspend = date("Y-m-d H:i:s", strtotime("+$duration days"));

        $stmt = $connection->prepare("UPDATE ".DB_PREFIX."user SET suspend = ? WHERE id = ?");
        $stmt->execute([$suspend, $userId]);

        // Si l'utilisateur suspendu est connecté, déconnectez-le
        if (isset($_SESSION["user"]) && $_SESSION["user"]["id"] == $userId) {
            session_unset();
            session_destroy();
        }

        // Redirigez l'utilisateur vers la liste des utilisateurs après avoir mis à jour la suspension
        header("Location: users.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Suspendre un utilisateur</title>
</head>
<body>
    <h1>Suspendre un utilisateur</h1>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) . '?id=' . $userId; ?>">
        <label for="duration">Durée de la suspension (en jours) :</label>
        <input type="number" name="duration" id="duration" min="1" required>
        <button type="submit">Suspendre</button>
    </form>
</body>
</html>
