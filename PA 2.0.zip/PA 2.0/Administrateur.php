<?php 
session_start();
require "conf.inc.php";
require "core/functions.php";
include "template/header.php";

?>

  <br>
  <br>
  <br>
  <br>
  
<style>



</style>
<div class="album py-5 bg-body-tertiary">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-10">
        <div class="card shadow-sm text-center">
          <div class="card-body">
            <h2 class="card-text">Utilisateurs</h2>
            <div class="d-flex justify-content-center">
              <a href='users.php' class='btn btn-danger'>Voir</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="album py-5 bg-body-tertiary">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-10">
        <div class="card shadow-sm text-center">
          <div class="card-body">
            <h2 class="card-text">Logs</h2>
            <div class="d-flex justify-content-center">
              <a href='logs.php' class='btn btn-danger'>Voir</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>


      
      

     