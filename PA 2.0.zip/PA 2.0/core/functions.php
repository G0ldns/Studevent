<?php

function helloWorld(){
	echo "Hello World";
}

//LOGS
function esgi_logs(){
	global $pageTitle;
	if(isConnected()){
		$user = $_SESSION['email'];
	} else {
		$user = "Non connecté";
	}
	$connection = connectDB();
	$queryPrepared = $connection->prepare("INSERT INTO ".DB_PREFIX."logs
											(visit_date, visit_hour, ip, page_visited, user)
											VALUES 
											(:visit_date, :visit_hour, :ip, :page_visited, :user)");
	$queryPrepared->execute([
								"visit_date"=>date("d/m/Y"),
								"visit_hour"=>date("H:i"),
								"ip"=>$_SERVER['REMOTE_ADDR'],
								"page_visited"=>$_SERVER['REQUEST_URI'],
								"user"=>$user
							]);
}
function cleanInput($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}

// Admin

function isAdmin($user) {
    return $user['user_role'] == 1;
}


// Prénom

function cleanFirstname($firstName){
	return ucwords(strtolower(trim($firstName)));
}

// Nom

function cleanLastname($lastName){
	return strtoupper(trim($lastName));
}

// EMAIL 

function cleanEmail($email){
	return strtolower(trim($email));
}

// PSEUDO 

function cleanPseudo($pseudo){
    return trim($pseudo);
}

// Connexion à la DB

function connectDB(){

	try{
		$connection = new PDO("mysql:host=".DB_HOST.";dbname=".DB_DATABASE.";port=".DB_PORT,DB_USER, DB_PWD);
	}catch(Exception $e){
		die("Erreur SQL ".$e->getMessage());
	}
	return $connection;
}



function isConnected(){
	if(!empty($_SESSION['email']) && !empty($_SESSION['login'])){
		$connection = connectDB();
		$queryPrepared = $connection->prepare("SELECT id FROM ".DB_PREFIX."user where email=:email");
		$queryPrepared->execute(["email"=>$_SESSION['email']]);
		$result = $queryPrepared->fetch();

		if(!empty($result)){
			return true;
		}
		
	}
	return false;
}

function redirectIfNotConnected(){
	if(!isConnected()){
		header("Location: login.php");
	}
}
