<?php

if (isset($_POST['search'])) {
    $search_query = $_POST['search_query'];
    $current_user_email = $_SESSION['email'];
    $connect = connectDB();
    $queryPrepared = $connect->prepare("SELECT * FROM ".DB_PREFIX."user WHERE pseudo LIKE :search_query AND email != :current_user_email");
    $queryPrepared->execute(['search_query' => '%' . $search_query . '%', 'current_user_email' => $current_user_email]);
    $results = $queryPrepared->fetchAll();

// vérifie si des résultats ont été trouvés

    if (count($results) > 0) {

// encode les résultats au format JSON

        $json_results = json_encode($results);

// définit une variable de session pour contenir les résultats de la recherche

        $_SESSION['search_results'] = $json_results;
    } else {
        $_SESSION['search_results'] = "No results found.";
    }

// rediriger l'utilisateur vers rechercheUser.php

    header("Location: searchUser.php");
    exit();
}

$pdo = null;

?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="" href="search.css">
</head>

<!-- Formulaire HTML avec la barre de recherche -->

<form method="post">
    <center><input type="text" name="search_query" placeholder="Recherche ..." >
</form>