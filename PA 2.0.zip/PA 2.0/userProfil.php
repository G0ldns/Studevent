<?php
session_start();
require "conf.inc.php";
require "core/functions.php";
include "template/header.php";

// Récupération de l'ID de l'utilisateur ($_Get = par l'url)
$user_id = $_GET['user_id'];

// Connexion à la base de données
$connect = connectDB();

// Requête pour récupérer les informations de l'utilisateur en fonction de l'ID
$queryPrepared = $connect->prepare("SELECT pseudo, firstname, lastname, gender, country, bio FROM ".DB_PREFIX."user WHERE id=:id");
$queryPrepared->execute(["id" => $user_id]);
$user = $queryPrepared->fetch();



?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Profil de <?= htmlspecialchars($user['pseudo']) ?></title>
    <link rel="stylesheet" type="" href="profil.css">
    <style>
        
        body {
    font-family: Centaur;
    background-color: beige;
    padding: 30px;
}

h1 {

    font-family: Bernard MT;

}

    </style>
</head>
<body>
    <br>
    <br>
    <br>
    <form>

        <div class="user-info">
            <p><label>Pseudo :</label> <input type="text" name="pseudo" value="<?= htmlspecialchars($user['pseudo']) ?>" readonly></p>

            <p>
            	<label>Prénom :</label> <input type="text" name="firstname" value="<?= htmlspecialchars($user['firstname']) ?>" readonly>
            </p>

            <p
            ><label>Nom :</label> <input type="text" name="lastname" value="<?= htmlspecialchars($user['lastname']) ?>" readonly>
            </p>

            <p>
            	<label>Genre :</label> <input type="text" name="gender" value="<?= htmlspecialchars($user['gender']) ?>" readonly>
            </p>

            <p>
            	<label>Pays :</label> <input type="text" name="country" value="<?= htmlspecialchars($user['country']) ?>" readonly>
            </p>

            <p>
            	<label>Bio :</label> <textarea name="bio" readonly><?= htmlspecialchars($user['bio']) ?></textarea>
            </p>

        </div>
        <div>
            
        </div>
    </form>
<br>
<br>
<br>

</body>
</html>


<?php include "template/footer.php";?>
<?php include "codeLogs.php";?>

